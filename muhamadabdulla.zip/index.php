


<table style="margin: auto;">
<?php
$arr = array("a","b","c","d","e","f","g","h");
for($row=1;$row<=8;$row++)
{
	echo "<tr>";
	for($col=1;$col<=8;$col++)
	{
		$x=$row+$col;
		if($x%2==1)
		{
			echo "<td height=45px width=40px bgcolor=#FFFFFF >".$col .' '.$arr[$row-1]."</td>";
		}
		else
		{
			echo "<td height=45px width=40px bgcolor=#878787>".$col.' '.$arr[$row-1]."</td>";
		}
	}
	echo "</tr>";
}
?>
</table>